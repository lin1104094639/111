#include <stdio.h>
#include <stdlib.h>
 
typedef struct node
{
   char c;
   int  count;
}nd;
 
int cmp(const void* p1, const void*p2)
{
    nd*c = (nd*)p1;
    nd*d = (nd*)p2;
    if(c->count != d->count) return d->count - c->count;
    else return c->c - d->c;
}
int main()
{
    nd a[26];
    int i;
    for(i=0;i<26;i++)
    {
        a[i].c='a'+i;
        a[i].count=0;
    }
     
    char s[128];
    while(scanf("%s",s)!=EOF)
    {
          for(i=0;s[i]!=0;i++)
          {
             a[s[i]-'a'].count++;
          }
          qsort(a,26,sizeof(a[0]),cmp);
          for(i=0;a[i].count;i++)
          {
              printf("%c %d\n",a[i].c,a[i].count);
          }
    }
    return 0;
}
