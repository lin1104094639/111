#include <iostream>
#include <cstring>
using namespace std; 

int main()  {
		int n;
		cin>>n;
		int price[11]={0,1,5,8,9,10,17,17,20,23,28};
		int *r=new int [n+1];
		for(int k = 0; k<= n; ++k)
			r[k] = 0; 
		for(int i = 1; i <= n; ++i)
		{          
			int q = INT_MIN;
			for(int j = 1; j <= i; ++j)
			{              
				if(q < (price[j] + r[i-j]))
					q = (price[j] + r[i-j]);  
			}          
			r[i] = q;  
		}
		cout<<r[n];  
	} 
